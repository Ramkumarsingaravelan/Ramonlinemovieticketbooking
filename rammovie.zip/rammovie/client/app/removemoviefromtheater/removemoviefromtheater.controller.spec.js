'use strict';

describe('Component: RemovemoviefromtheaterComponent', function () {

  // load the controller's module
  beforeEach(module('meanstackyeomanApp'));

  var RemovemoviefromtheaterComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    RemovemoviefromtheaterComponent = $componentController('removemoviefromtheater', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
