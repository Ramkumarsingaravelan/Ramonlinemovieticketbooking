'use strict';

angular.module('meanstackyeomanApp', ['meanstackyeomanApp.auth', 'meanstackyeomanApp.admin',
    'meanstackyeomanApp.constants', 'ngCookies', 'ngResource', 'ngSanitize', 'ngRoute',
    'btford.socket-io', 'validation.match'
  ])
  .config(function($routeProvider, $locationProvider) {
    $routeProvider.otherwise({
      redirectTo: '/'
    });
  


    $locationProvider.html5Mode(true);
  });
