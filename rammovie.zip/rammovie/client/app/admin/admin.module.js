'use strict';

angular.module('meanstackyeomanApp.admin', ['meanstackyeomanApp.auth', 'ngRoute']);
