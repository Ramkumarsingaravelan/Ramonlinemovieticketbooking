'use strict';

describe('Component: ShowtheaterComponent', function () {

  // load the controller's module
  beforeEach(module('meanstackyeomanApp'));

  var ShowtheaterComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    ShowtheaterComponent = $componentController('showtheater', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
