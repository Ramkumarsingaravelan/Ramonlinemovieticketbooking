'use strict';

(function(){

class ShowtheaterComponent {
  constructor($http, $scope, socket, $routeParams) {
    this.message = 'Hello';
    this.$http = $http;
    this.socket = socket;
    this.pickedTheatersAll = [];
    this.selectedDates=[];
    this.selectedTimes=[];
    this.theaters=[];
    this.mapping=[];
    this.pickedTheatersAll=[];
    this.movieId = "";
    this.theatreObj="";
    if ($routeParams){
      console.log($routeParams.param);
       this.movieId = $routeParams.param;
       //this.theatreObj=$routeParams.param;
       this.$http.get('/api/moviesendpoints/'+this.movieId).then(response=>{
         console.log(response.data);
         this.movie = response.data;
         this.socket.syncUpdates('moviesendpoint',this.movies);

         this.$http.get('/api/mappingendpoints').then(response1=>{
         console.log(response1.data);
         var mappingArray = response1.data;
         for (var variable in mappingArray) {
           console.log(this.movieId);
           if (mappingArray[variable].MovieObj == this.movieId){

             this.pickedTheatersAll.push(mappingArray[variable]);
        var mov=     this.movieId;

           }
         }

         this.socket.syncUpdates('mappingendpoint',this.mapping);


         });

       });
    }
  }
  $onInit(){


  }

}


angular.module('meanstackyeomanApp')
  .component('showtheater', {
    templateUrl: 'app/showtheater/showtheater.html',
    controller: ShowtheaterComponent,
    controllerAs: 'showtheaterCtrl'
  });

})();
