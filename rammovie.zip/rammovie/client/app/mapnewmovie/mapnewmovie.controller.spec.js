'use strict';

describe('Component: MapnewmovieComponent', function () {

  // load the controller's module
  beforeEach(module('meanstackyeomanApp'));

  var MapnewmovieComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    MapnewmovieComponent = $componentController('mapnewmovie', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
