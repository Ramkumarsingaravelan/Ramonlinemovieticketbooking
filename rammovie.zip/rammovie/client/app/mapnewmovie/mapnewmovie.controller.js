'use strict';

(function(){

class MapnewmovieComponent {

  constructor($http, $scope, socket,$rootScope) {
    this.$http = $http;
    this.socket = socket;
    this.message = 'Hello';
    this.movieId = '-1';
    this.selectedDates=[];
    this.selectedTimes=[];
    this.selectedTheaters = [];
    this.pickedTheaters = [];
    this.pickedTheatersAll = [];
    this.mapping=[];
  this.movies=[];
  this.theaters=[];
  }


  $onInit()
  {
    this.$http.get('/api/moviesendpoints').then(response=>{
      this.movies=response.data;
      console.log(this.movies);
    //  this.socket.syncUpdates('moviesendpoint',this.movies);
    });
    this.$http.get('/api/addtheaterendpoints').then(response=>{
      this.theaters=response.data;
      console.log(this.theaters);

    });




$("#datepicker").datepicker();
$('input.timepicker').timepicker({

    timeFormat: 'h:mm p',
    interval: 60,
    //minTime: '10',
    //maxTime: '6:00pm',
    //defaultTime: '11',
    //startTime: '10:00',
    dynamic: false,
    dropdown: true,
    scrollbar: true
});
//this.socket.syncUpdates('mappingendpoint',this.mappping);






}

onChangeMovie(){
  console.log(this.movieId);
}
savemap()
  {
    //console.log(this.pickedTheatersAll);
    //console.log(this.selectedTimes);



    this.$http.post('/api/mappingendpoints',{
        MovieObj:this.movieId,
        TheaterObj:this.pickedTheatersAll,
        Dates:this.selectedDates,
        Time:this.selectedTimes
    }).then(response => {
      this.$http.get('/api/mappingendpoints').then(response1=>{
            console.log(response1);
      //this.movieId=response1.data;
      //this.pickedTheatersAll=response1.data;
      //this.selectedDates=response1.data;
     //this.selectedTimes=response1.data;

      //this.socket.syncUpdates('mappingendpoint',this.mapping);

      });
    },failure=>{
      console.log(failure);
    });
alert("Record added Successfully");

}

onDateBtnClicked()
{
var d=$("#datepicker").val();
  //alert(d);
this.selectedDates.push(d);
console.log(this.selectedDates);

//this.socket.syncUpdates('mappingendpoint',this.selectedDates);
//sessionStorage.setItem('Dates',this.selectedDates);
//location.href='/modifyshowdatetimings';
}
removedates(ind)
{
//  $timeout(function () {
    this.selectedDates.splice(ind,1);
  //});

}

onTimeBtnClicked()
{
var t=$('input.timepicker').val();
//alert(t);
this.selectedTimes.push(t);
console.log(this.selectedTimes);

}
removetimes(index)
{
  //$timeout(function () {
this.selectedTimes.splice(index,1);
//});
}

  moveSelectionToRight(){
      var objs = angular.copy(this.selectedTheaters);
      for (var variable of this.theaters) {

        for (var obj of objs) {

          if (obj === variable._id){
           this.pickedTheatersAll.push(variable);
            this.theaters.splice(this.theaters.indexOf(variable),1);
            break;
          }
        }



        //console.log(variable);
      }


  }
  moveSelectionToLeft(){

    var objs = angular.copy(this.pickedTheaters);
    for (var variable of this.pickedTheatersAll) {

      for (var obj of objs) {
        console.log(obj);
        if (obj === variable._id){
          this.theaters.push(variable);
          console.log(variable);
          this.pickedTheatersAll.splice(this.pickedTheatersAll.indexOf(variable),1);
          break;
        }
      }



      //console.log(variable);
    }


  }
  moveSelectionToRightall(){

    var objs = angular.copy(this.pickedTheatersAll);
    this.pickedTheatersAll = [];
    for (var variable of objs) {
      this.theaters.push(variable);
      console.log(variable);
    }

    /*
      var objs = angular.copy(this.selectedTheaters);
  for (var variable of this.theaters) {
        for (var obj of objs) {
//console.log(objs);
        if (obj === variable._id){
           this.pickedTheatersAll.push(variable);
          this.theaters.splice(this.theaters.indexOf(variable),);
            break;
          }
        }




      //}


  }
  */


}
moveSelectionToLeftall(){

  var objs = angular.copy(this.theaters);
  this.theaters = [];
  for (var variable of objs) {
    this.pickedTheatersAll.push(variable);
    console.log(variable);
  }

/*
  var objs = angular.copy(this.pickedTheaters);
  for (var variable of this.pickedTheatersAll) {

    for (var obj of objs) {
      //console.log(obj);
      if (obj === variable._id){
        this.theaters.push(variable);
        //console.log(variable);
        this.pickedTheatersAll.splice(this.pickedTheatersAll.indexOf(variable));
        break;
      }
    }



    //console.log(variable);
  }

  */


}


}

angular.module('meanstackyeomanApp')
  .component('mapnewmovie', {
    templateUrl: 'app/mapnewmovie/mapnewmovie.html',
    controller: MapnewmovieComponent,
    controllerAs: 'mapnewmovieCtrl'
  });

})();
