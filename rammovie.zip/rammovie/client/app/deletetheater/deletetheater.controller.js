'use strict';

(function(){

class DeletetheaterComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.theater=[];
    this.selected = "-1";


    $scope.$on('$destroy', function() {
      socket.unsyncUpdates('theatre');
    });
    /*
show()
{
    this.$http.get('/api/addtheaterendpoints'{
      TheaterName:this.TheaterName,
      Location:this.Location,
      City:this.City
    });
}
show();
*/
   }

   onPickCity(){
     console.log(this.selected);
   }
}


angular.module('meanstackyeomanApp')
  .component('deletetheater', {
    templateUrl: 'app/deletetheater/deletetheater.html',
    controller: DeletetheaterComponent,
    controllerAs: 'deletetheaterCtrl'
  });

})();
