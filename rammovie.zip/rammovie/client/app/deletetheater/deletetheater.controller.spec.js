'use strict';

describe('Component: DeletetheaterComponent', function () {

  // load the controller's module
  beforeEach(module('meanstackyeomanApp'));

  var DeletetheaterComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    DeletetheaterComponent = $componentController('deletetheater', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
