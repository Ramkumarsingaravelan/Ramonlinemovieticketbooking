'use strict';

(function(){

class SuccessComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.$scope=$scope;
    //this.message = 'Hello';
  }
  $onInit(){
  //  document.getElementById('divposter').innerHTML=sessionStorage.getItem('Poster');
    document.getElementById('divTickets').innerHTML=sessionStorage.getItem('Ticket');
    document.getElementById('divTotal').innerHTML=sessionStorage.getItem('Total');
     document.getElementById('divSeatno').innerHTML=sessionStorage.getItem('Seatno');
     document.getElementById('divgold').innerHTML=sessionStorage.getItem('Gold');
     document.getElementById('divsliver').innerHTML=sessionStorage.getItem('Sliver');
     document.getElementById('divshowdate').innerHTML=sessionStorage.getItem('dates');
    document.getElementById('divshowtime').innerHTML=sessionStorage.getItem('times');
      document.getElementById('divshowmovie').innerHTML=sessionStorage.getItem('MovieName');
     document.getElementById('divshowTheater').innerHTML=sessionStorage.getItem('TheaterName');
     document.getElementById('divshowLocation').innerHTML=sessionStorage.getItem('Location');
      document.getElementById('divshowCity').innerHTML=sessionStorage.getItem('City');
  var res=sessionStorage.getItem("res");
   sessionStorage.clear();
  }

}

angular.module('meanstackyeomanApp')
  .component('success', {
    templateUrl: 'app/success/success.html',
    controller: SuccessComponent,
    controllerAs: 'successCtrl'
  });

})();
