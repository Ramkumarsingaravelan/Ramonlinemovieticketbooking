'use strict';

angular.module('meanstackyeomanApp')
  .config(function ($routeProvider) {
    $routeProvider
      .when('/success', {
        template: '<success></success>'
      });
  });
