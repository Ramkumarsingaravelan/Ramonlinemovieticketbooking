'use strict';

angular.module('meanstackyeomanApp')
  .config(function ($routeProvider) {
    $routeProvider
      .when('/editmoviemapping', {
        template: '<editmoviemapping></editmoviemapping>'
      });
  });
