'use strict';

(function(){

class EditmoviemappingComponent {
  constructor() {
    this.message = 'Hello';
  }
}

angular.module('meanstackyeomanApp')
  .component('editmoviemapping', {
    templateUrl: 'app/editmoviemapping/editmoviemapping.html',
    controller: EditmoviemappingComponent,
    controllerAs: 'editmoviemappingCtrl'
  });

})();
