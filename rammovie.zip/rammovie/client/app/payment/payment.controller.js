'use strict';

(function(){

class PaymentComponent {
  constructor($http, $scope, $location, socket) {
    this.$http = $http;
    this.socket = socket;
    this.$scope=$scope;
    this.CardNumber = '';
    this.CardName = '';
    this.CVV = '';

}
paid()
{
  console.log(this.CardNumber.length);
  if(this.CardNumber.length != 16)
  {
    alert('card number invalid');

  }
  else if(!this.CardName){
    alert('card name is invalid');
  }
  else if(this.CVV.length != 3)
  {
    alert('invalid cvv');
  }
  else {
    alert ('everything is correct');
    console.log("called");

        this.$http.post('/api/seatendpoints ',{
          seatno:(sessionStorage.Seatno).split(","),
          date:(sessionStorage.dates),
          time:(sessionStorage.times),
          movieId:(sessionStorage.movieId),
          TheaterId:(sessionStorage.theaterId)
      }).then(response => {
          this.$http.get('/api/seatendpoints ').then(response1=>{
            console.log(response.data);

          this.seat=response.data;
          this.socket.syncUpdates('seatendpoints',this.seat);
          window.location.href = '/success';
        });
      });
    return false;
  }


return true;

}


    $onInit(){
      document.getElementById('divTickets').innerHTML=sessionStorage.getItem('Ticket');
      document.getElementById('divTotal').innerHTML=sessionStorage.getItem('Total');
        document.getElementById('divSeatno').innerHTML=sessionStorage.getItem('Seatno');
        document.getElementById('divgold').innerHTML=sessionStorage.getItem('Gold');
        document.getElementById('divsliver').innerHTML=sessionStorage.getItem('Sliver');
        document.getElementById('divshowdate').innerHTML=sessionStorage.getItem('dates');
        document.getElementById('divshowtime').innerHTML=sessionStorage.getItem('times');
        document.getElementById('divshowmovie').innerHTML=sessionStorage.getItem('MovieName');
        document.getElementById('divshowTheater').innerHTML=sessionStorage.getItem('TheaterName');
        document.getElementById('divshowLocation').innerHTML=sessionStorage.getItem('Location');
       document.getElementById('divshowCity').innerHTML=sessionStorage.getItem('City');
    var id=sessionStorage.getItem("id");
  }

}
angular.module('meanstackyeomanApp')
  .component('payment', {
    templateUrl: 'app/payment/payment.html',
    controller: PaymentComponent,
    controllerAs: 'paymentCtrl'
  });

})();
