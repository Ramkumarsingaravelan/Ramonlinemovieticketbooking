'use strict';

angular.module('meanstackyeomanApp')
  .config(function ($routeProvider) {
    $routeProvider
      .when('/movies', {
        template: '<movies></movies>',
        authenticate:'admin'
      });
  });
