'use strict';

(function(){

class MoviesComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.movies=[];
    this.movies_search=[];
    $scope.$on('$destroy', function() {
      socket.unsyncUpdates('movies');
    });
  }
  findmovie()
  {
    this.$http.get('https://api.themoviedb.org/3/search/movie?api_key=fad4ab5ba39dbc4ce5fc1cd16fdf448a&query='+this.MovieName+'&year='+this.Year).then(response=>{
// this.$http.get('https://api.themoviedb.org/3/search/movie?api_key=fad4ab5ba39dbc4ce5fc1cd16fdf448a&query=sultan&year=2016').then(response=>{
   this.movies_search=response.data.results;
   console.log(this.movies_search);
   //this.socket.syncUpdates('moviesendpoint',this.movies_search);
   /*
      var movieid=response.data.results[0].id;
        this.$http.get('https://api.themoviedb.org/3/movie/'+movieid+'?api_key=fad4ab5ba39dbc4ce5fc1cd16fdf448a').then(movieres=>{
           this.movies=movieres.data;
          //console.log(this.movies);
          this.socket.syncUpdates('moviesendpoint',this.movies);
        });
        */
    });

  }
$onInit()
{
  this.$http.get('/api/moviesendpoints').then(response=>{
    this.movies=response.data;
    this.socket.syncUpdates('moviesendpoint',this.movies);
  });
}
removemovie(id){
  this.$http.delete('/api/moviesendpoints/'+id);
  this.socket.syncUpdates('moviesendpoint',this.movies);
}
  addmovie(movieObj)
  {
    //console.log(movieObj);
    this.$http.get('https://api.themoviedb.org/3/movie/'+movieObj.id+'?api_key=fad4ab5ba39dbc4ce5fc1cd16fdf448a').then(movieres=>{

      console.log(movieres.data);


          this.$http.post('/api/moviesendpoints',{
              Obj:movieres.data
          }).then(response => {
              this.$http.get('/api/moviesendpoints').then(response1=>{
              this.movies=response1.data;
              this.socket.syncUpdates('moviesendpoint',this.movies);
            });
          },failure=>{
            console.log(failure);
          });



    });

    //this.socket.syncUpdates('moviesendpoint',this.movies);

alert('Record Saved Successfully');
//this.MovieName="";
//this.Year="";
}
//windows.alert('Record Saved Successfully');
}


angular.module('meanstackyeomanApp')
  .component('movies', {
    templateUrl: 'app/movies/movies.html',
    controller: MoviesComponent,
    styleUrls:['app/movies/movies.css'],
    controllerAs: 'moviesCtrl'
  });

})();
