'use strict';

angular.module('meanstackyeomanApp')
  .config(function ($routeProvider) {
    $routeProvider
      .when('/sliverselection', {
        template: '<sliverselection></sliverselection>'
      });
  });
