'use strict';

describe('Component: SliverselectionComponent', function () {

  // load the controller's module
  beforeEach(module('meanstackyeomanApp'));

  var SliverselectionComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    SliverselectionComponent = $componentController('sliverselection', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
