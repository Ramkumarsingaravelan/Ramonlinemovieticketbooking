'use strict';

(function(){

class MovieratingComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;

    this.mapping=[];
    this.movies=[];
    this.ratingObj = {};
    //this.theaters=[];
    this.selectedMovieMapObj = {};
  //this.pickedTheatersAll=[];
  this.rating='';
  this.userId='';
  this.movieId='';


    $scope.$on('$destroy', function() {
      socket.unsyncUpdates('movierating');
    });
  }
  $onInit() {

      this.$http.get('/api/moviesendpoints').then(response=>{
        this.movies=response.data;
        console.log(this.movies);
      //  this.socket.syncUpdates('moviesendpoint',this.movies);
      });
      this.$http.get('/api/mappingendpoints').then(response1=>{
      console.log(response1);
      this.movieId=response1.data;
      this.pickedTheatersAll=response1.data;
      //this.selectedDates=response1.data;
     //this.selectedTimes=response1.data;

      //this.socket.syncUpdates('mappingendpoint',this.mapping);

      });
        this.$http.get('/api/movieratingendpoints').then(response=>{

            response.data.forEach(obj =>{
              console.log(obj);
              var rMovieId = obj.movieId;
              var rUserId = obj.userId;
              var rRating = obj.rating;

              if (this.ratingObj[rMovieId+'_count']){
                this.ratingObj[rMovieId+'_count'] = this.ratingObj[rMovieId+'_count']+1;
              }else{
                this.ratingObj[rMovieId+'_count'] = 1;
              }


              if (this.ratingObj[rMovieId+'_total']){
                this.ratingObj[rMovieId+'_total'] = parseInt(this.ratingObj[rMovieId+'_total'])+rRating;
              }else{
                this.ratingObj[rMovieId+'_total'] = rRating;
              }

              this.ratingObj[rMovieId+'_'+rUserId] = true;
            });
            console.log(this.ratingObj);
            this.loadRating();

    });




  }


  loadRating(){
    this.movies.forEach(movie =>{
      var readOnly = false;
      var scoreExisting = 0;
      if (this.ratingObj[movie._id+'_total'] && this.ratingObj[movie._id+'_count']){
        scoreExisting = this.ratingObj[movie._id+'_total']/this.ratingObj[movie._id+'_count'];
      }
      if (this.ratingObj[movie._id+'_'+localStorage.email]){
        //already rated
        readOnly = true;

      }else{
        //allow rating

      }

      $('#rat'+movie._id).html(Math.round(scoreExisting * 100) / 100);
      $('#static-review'+movie._id).raty({
            readOnly:readOnly,
            score:scoreExisting,
            click: (score, evt) => {
            //console.log('ID: ' + this.id + "\nscore: " + score + "\nevent: " + evt);

            $('#rat'+movie._id).html(score);

           this.$http.post('/api/movieratingendpoints',{
             movieId:movie._id,
             rating:score,
             userId:localStorage.email
           }).then(response1=>{
              console.log(response1);
           });

            //this.socket.syncUpdates('mappingendpoint',this.mapping);
            console.log(score);
        }

      });
    });
}

}

angular.module('meanstackyeomanApp')
  .component('movierating', {
    templateUrl: 'app/movierating/movierating.html',
    controller: MovieratingComponent,
    controllerAs: 'movieratingCtrl'
  });

})();
