'use strict';

(function(){

class ModifyshowdatetimingsComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.mapping=[];
    this.movies=[];
    this.theaters=[];
    this.selectedDates=[];
    this.selectedTimes=[];
    this.pickedTheatersAll = [];
    this.selectedTheater = '-1';
    this.movieId = '-1';
  }
  $onInit()
  {
    this.$http.get('/api/moviesendpoints').then(response=>{
      this.movies=response.data;
      console.log(this.movies);
    //  this.socket.syncUpdates('moviesendpoint',this.movies);
    });

    this.$http.get('/api/mappingendpoints').then(response1=>{
    console.log(response1);
    //this.movieId=response1.data;
    this.pickedTheatersAll=response1.data;

    //this.selectedDates=response1.data;
   //this.selectedTimes=response1.data;

    //this.socket.syncUpdates('mappingendpoint',this.mapping);
      //console.log(this.movieId);

    });
    $("#datepicker").datepicker();
    $('input.timepicker').timepicker({

        timeFormat: 'h:mm p',
        interval: 60,
        minTime: '10',
        maxTime: '6:00pm',
        defaultTime: '11',
        startTime: '10:00',
        dynamic: false,
        dropdown: true,
        scrollbar: true
    });
    //this.selectedDates=sessionStorage.getItem('Dates');
  }
  savemodifymap()
  {
    this.$http.post('/api/mappingendpoints',{
        MovieObj:this.movieId,
        TheaterObj:this.selectedTheaters,
        Dates:this.selectedDates,
        Time:this.selectedTimes
    }).then(response => {
      this.$http.get('/api/mappingendpoints').then(response2=>{
      console.log(response2);
      //this.movieId=response1.data;
        this.pickedTheatersAll=response2.data;

        console.log(this.pickedTheatersAll);
    //  this.selectedDates=response1.data;
      //this.selectedTimes=response1.data;

      this.socket.syncUpdates('mappingendpoint',this.mapping);
      //console.log(this.movieId);

      });
    },failure=>{
      console.log(failure);
    });
alert("Record modify Successfully");

}

onChangeMovie(){
  console.log(this.movieId);
  this.theaters = [];

  this.selectedDates=[];
  this.selectedTimes=[];
  this.selectedTheater = '-1';
  if (this.movieId != '-1'){

    for (var index in this.pickedTheatersAll) {
      console.log(this.pickedTheatersAll[index]);
      var obj = this.pickedTheatersAll[index];
      if (obj.MovieObj == this.movieId){
        if (this.selectedDates.length == 0){
          this.selectedDates = obj.Dates;
        }
        if (this.selectedTimes.length == 0){
         this.selectedTimes = obj.Time;
      }
        for (var thIndex in obj.TheaterObj) {
     this.theaters.push(obj.TheaterObj[thIndex]);
       }

      }
   }
  }
}

  onDateBtnClicked()
  {

    var d=$("#datepicker").val();
    //alert(d);
  this.selectedDates.push(d);
  console.log(this.selectedDates);
  //this.socket.syncUpdates('mappingendpoint',this.selectedDates);
  }
  removedates(ind)
  {
  this.selectedDates.splice(ind,1);
  }

  onTimeBtnClicked()
  {
  var t=$('input.timepicker').val();
  //alert(t);
  this.selectedTimes.push(t);
  console.log(this.selectedTimes);

  }
  removetimes(index)
  {
  this.selectedTimes.splice(index,1);
  }
}

angular.module('meanstackyeomanApp')
  .component('modifyshowdatetimings', {
    templateUrl: 'app/modifyshowdatetimings/modifyshowdatetimings.html',
    controller: ModifyshowdatetimingsComponent,
    controllerAs: 'modifyshowdatetimingsCtrl'
  });

})();
