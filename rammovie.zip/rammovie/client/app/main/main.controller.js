'use strict';

(function() {

  class MainController {

    constructor($http, $scope, socket) {
      this.$http = $http;
      this.socket = socket;
      this.awesomeThings = [];
      this.mapping=[];
      this.movies=[];
      this.theaters=[];
      this.selectedMovieMapObj = {};
    this.pickedTheatersAll=[];

      $scope.$on('$destroy', function() {
        socket.unsyncUpdates('thing');
      });
    }


    $onInit() {
      this.$http.get('/api/things')
        .then(response => {
          this.awesomeThings = response.data;
          this.socket.syncUpdates('thing', this.awesomeThings);
        });
        this.$http.get('/api/moviesendpoints').then(response=>{
          this.movies=response.data;
          console.log(this.movies);
        //  this.socket.syncUpdates('moviesendpoint',this.movies);
        });
        this.$http.get('/api/mappingendpoints').then(response1=>{
        console.log(response1);
        this.movieId=response1.data;
        this.pickedTheatersAll=response1.data;
        //this.selectedDates=response1.data;
       //this.selectedTimes=response1.data;

        //this.socket.syncUpdates('mappingendpoint',this.mapping);

        });
    }

    addThing() {
      if (this.newThing) {
        this.$http.post('/api/things', {
          name: this.newThing
        });
        this.newThing = '';
      }
    }

    deleteThing(thing) {
      this.$http.delete('/api/things/' + thing._id);
    }

    //myFunction(img)
    //{
        //$("#img1").html('<img src="assets/images/img/'+img+'" class="img-responsive" >');
      //  $("#img_holder").html('<img src="assets/images/img/'+img+'" class="img-responsive">');
      //  console.log(img);
    //}
    //goldvalue(){
      //location.href='/seatselection';
    //}
    //slivervalue(){
    //  location.href='/sliverselection';
    //}
    book(mid){
      console.log("called");
      location.href='/showtheater/'+mid;


    }
  }

  angular.module('meanstackyeomanApp')
    .component('main', {
      templateUrl: 'app/main/main.html',
      controller: MainController,
      controllerAs: 'mainController'
    });
})();
