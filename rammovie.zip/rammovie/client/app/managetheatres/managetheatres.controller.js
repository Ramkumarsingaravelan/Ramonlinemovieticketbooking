'use strict';

(function(){

class ManagetheatresComponent {

  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.theater=[];
    this.selectedId = 1;
    $scope.$on('$destroy', function() {
      socket.unsyncUpdates('theatre');
    });
  }
/*  addtheater()
  {
    this.$http.post('/api/managetheatresendpoints',{
      TheaterName:this.TheaterName,
      Location:this.Location,
      City:this.City
  });
  alert('Record Saved Successfully');
}*/

  loadComponent(compId){
    console.log(compId);
    this.selectedId = compId;
  }
}

angular.module('meanstackyeomanApp')
  .component('managetheatres', {
    templateUrl: 'app/managetheatres/managetheatres.html',
    controller: ManagetheatresComponent,
    controllerAs: 'managetheatresCtrl'
  });

})();
