'use strict';

(function(){

class AddtheaterComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.theater=[];


    $scope.$on('$destroy', function() {
      socket.unsyncUpdates('theater');
    });
   }


   $onInit()
   {
     this.$http.get('/api/addtheaterendpoints').then(response=>{
       this.theater=response.data;
       console.log(this.theater);
       this.socket.syncUpdates('addtheaterendpoint',this.theater);
     });
   }

  addtheater()
  {
console.log("called");

    this.$http.post('/api/addtheaterendpoints',{
      TheaterName:this.TheaterName,
      Location:this.Location,
      City:this.City
  }).then(response => {
      this.$http.get('/api/addtheaterendpoints').then(response1=>{
      this.theatre=response.data;
      this.socket.syncUpdates('addtheaterendpoint',this.theater);
    });
  });
  this.TheaterName='';
  this.Location='';
  this.City='';
  alert("Record saved Successfully");
}
removetheater(id){
  this.$http.delete('/api/addtheaterendpoints/'+id);
  this.socket.syncUpdates('addtheaterendpoint',this.theater);
}

}


angular.module('meanstackyeomanApp')
  .component('addtheater', {
    templateUrl: 'app/addtheater/addtheater.html',
    controller: AddtheaterComponent,
    controllerAs: 'addtheaterCtrl'
  });

})();
