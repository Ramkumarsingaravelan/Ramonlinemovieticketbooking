'use strict';

(function(){

class ShowdateComponent {
  constructor($http, $scope, socket, $routeParams) {
    this.message = 'Hello';
    this.$http = $http;
    this.socket = socket;
    this.theaterId = '';
    this.mapId = '';
    this.theaterObj = {};
    this.movieId = '';
    this.mappingObj = {};
    this.date=[];
//this.showdts=false;
//this.showtic=false;
    if ($routeParams){
      this.theaterId = $routeParams.thid;
      console.log(this.theaterId);
      this.mapId = $routeParams.mapid;
      this.movieId = $routeParams.movieid;
      this.selectedDate = '';

      this.$http.get('/api/moviesendpoints/'+this.movieId).then(response=>{
        console.log(response.data);
        this.movie = response.data;
        var Movieobj=this.movie;
        sessionStorage.setItem('MovieName',Movieobj.Obj.title);
        sessionStorage.setItem('Poster',Movieobj.Obj.poster_path);
        sessionStorage.setItem('movieId',this.movieId);
        sessionStorage.setItem('theaterId',this.theaterId);
        sessionStorage.setItem('mapId',this.mapId);
        this.socket.syncUpdates('moviesendpoint',this.movies);

        this.$http.get('/api/mappingendpoints/'+this.mapId).then(response1=>{

        this.mappingObj = response1.data;
        console.log(this.mappingObj);
        var theaters = this.mappingObj.TheaterObj;

        for (var variable in theaters) {

          if (theaters[variable]._id == this.theaterId){

            var Obj= this.theaterObj = theaters[variable];

            sessionStorage.setItem('TheaterName',Obj.TheaterName);
            sessionStorage.setItem('Location',Obj.Location);
            sessionStorage.setItem('City',Obj.City);
          }
        }

        this.socket.syncUpdates('mappingendpoint',this.mapping);


        });

      });
    }
  }

  selectedDates(dts)
  {
this.showdts=true;
    //alert(dts);
  var date=this.result=dts;

sessionStorage.setItem('dates',dts);
}
  selectedtimes(time)
{
this.showtic=true;
  console.log(time);
  this.res=time;
  sessionStorage.setItem('times',time);
}
//gold()
//{

//}

}

angular.module('meanstackyeomanApp')
  .component('showdate', {
    templateUrl: 'app/showdate/showdate.html',
    controller: ShowdateComponent,
    controllerAs: 'showdateCtrl'
  });

})();
