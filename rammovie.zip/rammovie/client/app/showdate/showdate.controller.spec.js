'use strict';

describe('Component: ShowdateComponent', function () {

  // load the controller's module
  beforeEach(module('meanstackyeomanApp'));

  var ShowdateComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    ShowdateComponent = $componentController('showdate', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
