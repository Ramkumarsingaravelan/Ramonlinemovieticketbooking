'use strict';

angular.module('meanstackyeomanApp.util', []);
