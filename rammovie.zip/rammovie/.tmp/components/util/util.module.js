'use strict';

angular.module('meanstackyeomanApp.util', []);
//# sourceMappingURL=util.module.js.map
