'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var ModifyshowdatetimingsComponent = function () {
    function ModifyshowdatetimingsComponent($http, $scope, socket) {
      _classCallCheck(this, ModifyshowdatetimingsComponent);

      this.$http = $http;
      this.socket = socket;
      this.mapping = [];
      this.movies = [];
      this.theaters = [];
      this.selectedDates = [];
      this.selectedTimes = [];
      this.pickedTheatersAll = [];
      this.selectedTheater = '-1';
      this.movieId = '-1';
    }

    _createClass(ModifyshowdatetimingsComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/moviesendpoints').then(function (response) {
          _this.movies = response.data;
          console.log(_this.movies);
          //  this.socket.syncUpdates('moviesendpoint',this.movies);
        });

        this.$http.get('/api/mappingendpoints').then(function (response1) {
          console.log(response1);
          //this.movieId=response1.data;
          _this.pickedTheatersAll = response1.data;

          //this.selectedDates=response1.data;
          //this.selectedTimes=response1.data;

          //this.socket.syncUpdates('mappingendpoint',this.mapping);
          //console.log(this.movieId);
        });
        $("#datepicker").datepicker();
        $('input.timepicker').timepicker({

          timeFormat: 'h:mm p',
          interval: 60,
          minTime: '10',
          maxTime: '6:00pm',
          defaultTime: '11',
          startTime: '10:00',
          dynamic: false,
          dropdown: true,
          scrollbar: true
        });
        //this.selectedDates=sessionStorage.getItem('Dates');
      }
    }, {
      key: 'savemodifymap',
      value: function savemodifymap() {
        var _this2 = this;

        this.$http.post('/api/mappingendpoints', {
          MovieObj: this.movieId,
          TheaterObj: this.selectedTheaters,
          Dates: this.selectedDates,
          Time: this.selectedTimes
        }).then(function (response) {
          _this2.$http.get('/api/mappingendpoints').then(function (response2) {
            console.log(response2);
            //this.movieId=response1.data;
            _this2.pickedTheatersAll = response2.data;

            console.log(_this2.pickedTheatersAll);
            //  this.selectedDates=response1.data;
            //this.selectedTimes=response1.data;

            _this2.socket.syncUpdates('mappingendpoint', _this2.mapping);
            //console.log(this.movieId);
          });
        }, function (failure) {
          console.log(failure);
        });
        alert("Record modify Successfully");
      }
    }, {
      key: 'onChangeMovie',
      value: function onChangeMovie() {
        console.log(this.movieId);
        this.theaters = [];

        this.selectedDates = [];
        this.selectedTimes = [];
        this.selectedTheater = '-1';
        if (this.movieId != '-1') {

          for (var index in this.pickedTheatersAll) {
            console.log(this.pickedTheatersAll[index]);
            var obj = this.pickedTheatersAll[index];
            if (obj.MovieObj == this.movieId) {
              if (this.selectedDates.length == 0) {
                this.selectedDates = obj.Dates;
              }
              if (this.selectedTimes.length == 0) {
                this.selectedTimes = obj.Time;
              }
              for (var thIndex in obj.TheaterObj) {
                this.theaters.push(obj.TheaterObj[thIndex]);
              }
            }
          }
        }
      }
    }, {
      key: 'onDateBtnClicked',
      value: function onDateBtnClicked() {

        var d = $("#datepicker").val();
        //alert(d);
        this.selectedDates.push(d);
        console.log(this.selectedDates);
        //this.socket.syncUpdates('mappingendpoint',this.selectedDates);
      }
    }, {
      key: 'removedates',
      value: function removedates(ind) {
        this.selectedDates.splice(ind, 1);
      }
    }, {
      key: 'onTimeBtnClicked',
      value: function onTimeBtnClicked() {
        var t = $('input.timepicker').val();
        //alert(t);
        this.selectedTimes.push(t);
        console.log(this.selectedTimes);
      }
    }, {
      key: 'removetimes',
      value: function removetimes(index) {
        this.selectedTimes.splice(index, 1);
      }
    }]);

    return ModifyshowdatetimingsComponent;
  }();

  angular.module('meanstackyeomanApp').component('modifyshowdatetimings', {
    templateUrl: 'app/modifyshowdatetimings/modifyshowdatetimings.html',
    controller: ModifyshowdatetimingsComponent,
    controllerAs: 'modifyshowdatetimingsCtrl'
  });
})();
//# sourceMappingURL=modifyshowdatetimings.controller.js.map
