'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var MovieratingComponent = function () {
    function MovieratingComponent($http, $scope, socket) {
      _classCallCheck(this, MovieratingComponent);

      this.$http = $http;
      this.socket = socket;

      this.mapping = [];
      this.movies = [];
      this.ratingObj = {};
      //this.theaters=[];
      this.selectedMovieMapObj = {};
      //this.pickedTheatersAll=[];
      this.rating = '';
      this.userId = '';
      this.movieId = '';

      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('movierating');
      });
    }

    _createClass(MovieratingComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/moviesendpoints').then(function (response) {
          _this.movies = response.data;
          console.log(_this.movies);
          //  this.socket.syncUpdates('moviesendpoint',this.movies);
        });
        this.$http.get('/api/mappingendpoints').then(function (response1) {
          console.log(response1);
          _this.movieId = response1.data;
          _this.pickedTheatersAll = response1.data;
          //this.selectedDates=response1.data;
          //this.selectedTimes=response1.data;

          //this.socket.syncUpdates('mappingendpoint',this.mapping);
        });
        this.$http.get('/api/movieratingendpoints').then(function (response) {

          response.data.forEach(function (obj) {
            console.log(obj);
            var rMovieId = obj.movieId;
            var rUserId = obj.userId;
            var rRating = obj.rating;

            if (_this.ratingObj[rMovieId + '_count']) {
              _this.ratingObj[rMovieId + '_count'] = _this.ratingObj[rMovieId + '_count'] + 1;
            } else {
              _this.ratingObj[rMovieId + '_count'] = 1;
            }

            if (_this.ratingObj[rMovieId + '_total']) {
              _this.ratingObj[rMovieId + '_total'] = parseInt(_this.ratingObj[rMovieId + '_total']) + rRating;
            } else {
              _this.ratingObj[rMovieId + '_total'] = rRating;
            }

            _this.ratingObj[rMovieId + '_' + rUserId] = true;
          });
          console.log(_this.ratingObj);
          _this.loadRating();
        });
      }
    }, {
      key: 'loadRating',
      value: function loadRating() {
        var _this2 = this;

        this.movies.forEach(function (movie) {
          var readOnly = false;
          var scoreExisting = 0;
          if (_this2.ratingObj[movie._id + '_total'] && _this2.ratingObj[movie._id + '_count']) {
            scoreExisting = _this2.ratingObj[movie._id + '_total'] / _this2.ratingObj[movie._id + '_count'];
          }
          if (_this2.ratingObj[movie._id + '_' + localStorage.email]) {
            //already rated
            readOnly = true;
          } else {
            //allow rating

          }

          $('#rat' + movie._id).html(Math.round(scoreExisting * 100) / 100);
          $('#static-review' + movie._id).raty({
            readOnly: readOnly,
            score: scoreExisting,
            click: function click(score, evt) {
              //console.log('ID: ' + this.id + "\nscore: " + score + "\nevent: " + evt);

              $('#rat' + movie._id).html(score);

              _this2.$http.post('/api/movieratingendpoints', {
                movieId: movie._id,
                rating: score,
                userId: localStorage.email
              }).then(function (response1) {
                console.log(response1);
              });

              //this.socket.syncUpdates('mappingendpoint',this.mapping);
              console.log(score);
            }

          });
        });
      }
    }]);

    return MovieratingComponent;
  }();

  angular.module('meanstackyeomanApp').component('movierating', {
    templateUrl: 'app/movierating/movierating.html',
    controller: MovieratingComponent,
    controllerAs: 'movieratingCtrl'
  });
})();
//# sourceMappingURL=movierating.controller.js.map
