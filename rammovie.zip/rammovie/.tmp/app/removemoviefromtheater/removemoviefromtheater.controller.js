'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var RemovemoviefromtheaterComponent = function () {
    function RemovemoviefromtheaterComponent($http, $scope, socket) {
      _classCallCheck(this, RemovemoviefromtheaterComponent);

      this.$http = $http;
      this.socket = socket;
      this.mapping = [];
      this.movies = [];
      this.theaters = [];
      this.selectedMovieMapObj = {};
      this.pickedTheatersAll = [];
    }

    _createClass(RemovemoviefromtheaterComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/moviesendpoints').then(function (response) {
          _this.movies = response.data;
          console.log(_this.movies);
          //  this.socket.syncUpdates('moviesendpoint',this.movies);
        });

        this.$http.get('/api/mappingendpoints').then(function (response2) {
          console.log(response2);
          //this.movieId=response1.data;
          _this.pickedTheatersAll = response2.data;

          console.log(_this.pickedTheatersAll);
          //  this.selectedDates=response1.data;
          //this.selectedTimes=response1.data;

          _this.socket.syncUpdates('mappingendpoint', _this.mapping);
          //console.log(this.movieId);
        });
      }
    }, {
      key: 'onChangeMovies',
      value: function onChangeMovies() {
        console.log(this.movieId);
        this.theaters = [];
        this.selectedTheater = '-1';
        this.selectedMovieMapObj = {};
        if (this.movieId != '-1') {
          for (var index in this.pickedTheatersAll) {
            console.log(this.pickedTheatersAll[index]);
            var obj = this.pickedTheatersAll[index];
            if (obj.MovieObj == this.movieId) {
              this.selectedMovieMapObj = obj;
              if (this.theaters.length == 0) {
                this.theaters = obj.TheaterObj;
              }
            }
          }
        }

        //}
        //}

      }
    }, {
      key: 'removetheater',
      value: function removetheater(index) {
        this.theaters.splice(index, 1);

        //  this.selectedMovieMapObj.TheaterObj = angular.copy(this.theaters);
        var st = JSON.stringify(this.selectedMovieMapObj);
        console.log(st);
        var obj = JSON.parse(st);
        obj.TheaterObj = JSON.parse(JSON.stringify(this.theaters));
        //delete obj.__v;
        console.log(obj);
        var id = obj._id;
        //delete obj._id;

        this.$http.delete('/api/mappingendpoints/' + id).then(function (response) {
          console.log(response);
          console.log('response');

          //this.socket.syncUpdates('mappingendpoint',this.mapping);
          //console.log(this.movieId);
        });
      }
    }]);

    return RemovemoviefromtheaterComponent;
  }();

  angular.module('meanstackyeomanApp').component('removemoviefromtheater', {
    templateUrl: 'app/removemoviefromtheater/removemoviefromtheater.html',
    controller: RemovemoviefromtheaterComponent,
    controllerAs: 'removemoviefromtheaterCtrl'
  });
})();
//# sourceMappingURL=removemoviefromtheater.controller.js.map
