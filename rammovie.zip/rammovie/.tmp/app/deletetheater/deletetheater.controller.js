'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var DeletetheaterComponent = function () {
    function DeletetheaterComponent($http, $scope, socket) {
      _classCallCheck(this, DeletetheaterComponent);

      this.$http = $http;
      this.socket = socket;
      this.theater = [];
      this.selected = "-1";

      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('theatre');
      });
      /*
      show()
      {
      this.$http.get('/api/addtheaterendpoints'{
        TheaterName:this.TheaterName,
        Location:this.Location,
        City:this.City
      });
      }
      show();
      */
    }

    _createClass(DeletetheaterComponent, [{
      key: 'onPickCity',
      value: function onPickCity() {
        console.log(this.selected);
      }
    }]);

    return DeletetheaterComponent;
  }();

  angular.module('meanstackyeomanApp').component('deletetheater', {
    templateUrl: 'app/deletetheater/deletetheater.html',
    controller: DeletetheaterComponent,
    controllerAs: 'deletetheaterCtrl'
  });
})();
//# sourceMappingURL=deletetheater.controller.js.map
