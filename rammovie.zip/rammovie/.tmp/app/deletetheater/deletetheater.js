'use strict';

angular.module('meanstackyeomanApp').config(function ($routeProvider) {
  $routeProvider.when('/deletetheater', {
    template: '<deletetheater></deletetheater>'
  });
});
//# sourceMappingURL=deletetheater.js.map
