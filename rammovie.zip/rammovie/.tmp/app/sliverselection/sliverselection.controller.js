'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var SliverselectionComponent = function () {
    function SliverselectionComponent($http, $scope, socket) {
      _classCallCheck(this, SliverselectionComponent);

      this.$http = $http;
      this.socket = socket;
      this.seat = [];
      this.seatno = [];
      //  this.message = 'Hello';
      var theTotal = 0;

      var ticket = 0;
      var total = 0;
      var s = 1;

      var tickets = [];
      var ctx = this;

      $(document).ready(function () {

        $('.se').attr('disabled', true);
        GetDateTimeFunction();

        var price = 60;

        $(".se").bind('click', function () {
          $(this).unbind('click');
          $(this).toggleClass("seatselect");

          var sliver = 'Sliver';
          $('#sliver').html(sliver);
          sessionStorage.setItem('Sliver', sliver);

          theTotal = Number(theTotal + price) + Number($(this).val());
          $('#total').html(+theTotal);
          ticket = Number(ticket + s) + Number($(this).val());

          sessionStorage.setItem('Total', theTotal);
          sessionStorage.setItem('Ticket', ticket);
          $('#ticket').html("Ticket: " + ticket);

          var seid = $(this).attr('id');
          console.log(seid);

          //var seatid=$(this).attr('id');
          console.log(ctx.seatno);
          var index = ctx.seatno.indexOf(seid);
          if (index == -1) {
            ctx.seatno.push(seid);
          } else {
            ctx.seatno.splice(index, 1);
          }

          $("#book").html("seat No:" + ctx.seatno);
          sessionStorage.setItem('Seatno', ctx.seatno);
        });
        function GetDateTimeFunction() {
          var DateTime = new Date();
          $("#divdatetime").html(DateTime);
        }
      });
    }

    _createClass(SliverselectionComponent, [{
      key: '$onInit',
      value: function $onInit() {

        this.$http.get('/api/seatendpoints ').then(function (response1) {

          var allBookings = response1.data;

          for (var index in allBookings) {
            var booking = allBookings[index];
            if (booking.TheaterId == sessionStorage.theaterId && booking.movieId == sessionStorage.movieId && booking.date == sessionStorage.dates && booking.time == sessionStorage.times) {
              console.log(booking);
              var bookedSeats = booking.seatno;
              for (var sIndex in bookedSeats) {
                var seat = bookedSeats[sIndex];
                $("#" + seat).unbind('click');
                $("#" + seat).toggleClass("seatbooked");
              }
            }
          }
        });
      }
    }, {
      key: 'sliver',
      value: function sliver() {
        console.log(this.seatno);

        if (this.seatno.length == 0) {
          alert("please select seat");
        } else {
          location.href = '/payment';
        }
      }
    }]);

    return SliverselectionComponent;
  }();

  angular.module('meanstackyeomanApp').component('sliverselection', {
    templateUrl: 'app/sliverselection/sliverselection.html',
    controller: SliverselectionComponent,
    controllerAs: 'sliverselectionCtrl'
  });
})();
//# sourceMappingURL=sliverselection.controller.js.map
