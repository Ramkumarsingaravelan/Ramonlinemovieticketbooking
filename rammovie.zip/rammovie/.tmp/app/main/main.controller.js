'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var MainController = function () {
    function MainController($http, $scope, socket) {
      _classCallCheck(this, MainController);

      this.$http = $http;
      this.socket = socket;
      this.awesomeThings = [];
      this.mapping = [];
      this.movies = [];
      this.theaters = [];
      this.selectedMovieMapObj = {};
      this.pickedTheatersAll = [];

      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('thing');
      });
    }

    _createClass(MainController, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/things').then(function (response) {
          _this.awesomeThings = response.data;
          _this.socket.syncUpdates('thing', _this.awesomeThings);
        });
        this.$http.get('/api/moviesendpoints').then(function (response) {
          _this.movies = response.data;
          console.log(_this.movies);
          //  this.socket.syncUpdates('moviesendpoint',this.movies);
        });
        this.$http.get('/api/mappingendpoints').then(function (response1) {
          console.log(response1);
          _this.movieId = response1.data;
          _this.pickedTheatersAll = response1.data;
          //this.selectedDates=response1.data;
          //this.selectedTimes=response1.data;

          //this.socket.syncUpdates('mappingendpoint',this.mapping);
        });
      }
    }, {
      key: 'addThing',
      value: function addThing() {
        if (this.newThing) {
          this.$http.post('/api/things', {
            name: this.newThing
          });
          this.newThing = '';
        }
      }
    }, {
      key: 'deleteThing',
      value: function deleteThing(thing) {
        this.$http.delete('/api/things/' + thing._id);
      }

      //myFunction(img)
      //{
      //$("#img1").html('<img src="assets/images/img/'+img+'" class="img-responsive" >');
      //  $("#img_holder").html('<img src="assets/images/img/'+img+'" class="img-responsive">');
      //  console.log(img);
      //}
      //goldvalue(){
      //location.href='/seatselection';
      //}
      //slivervalue(){
      //  location.href='/sliverselection';
      //}

    }, {
      key: 'book',
      value: function book(mid) {
        console.log("called");
        location.href = '/showtheater/' + mid;
      }
    }]);

    return MainController;
  }();

  angular.module('meanstackyeomanApp').component('main', {
    templateUrl: 'app/main/main.html',
    controller: MainController,
    controllerAs: 'mainController'
  });
})();
//# sourceMappingURL=main.controller.js.map
