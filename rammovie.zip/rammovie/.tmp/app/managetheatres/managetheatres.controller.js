'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var ManagetheatresComponent = function () {
    function ManagetheatresComponent($http, $scope, socket) {
      _classCallCheck(this, ManagetheatresComponent);

      this.$http = $http;
      this.socket = socket;
      this.theater = [];
      this.selectedId = 1;
      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('theatre');
      });
    }
    /*  addtheater()
      {
        this.$http.post('/api/managetheatresendpoints',{
          TheaterName:this.TheaterName,
          Location:this.Location,
          City:this.City
      });
      alert('Record Saved Successfully');
    }*/

    _createClass(ManagetheatresComponent, [{
      key: 'loadComponent',
      value: function loadComponent(compId) {
        console.log(compId);
        this.selectedId = compId;
      }
    }]);

    return ManagetheatresComponent;
  }();

  angular.module('meanstackyeomanApp').component('managetheatres', {
    templateUrl: 'app/managetheatres/managetheatres.html',
    controller: ManagetheatresComponent,
    controllerAs: 'managetheatresCtrl'
  });
})();
//# sourceMappingURL=managetheatres.controller.js.map
