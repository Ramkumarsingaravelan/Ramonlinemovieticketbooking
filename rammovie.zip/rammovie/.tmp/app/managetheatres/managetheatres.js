'use strict';

angular.module('meanstackyeomanApp').config(function ($routeProvider) {
  $routeProvider.when('/managetheatres', {
    template: '<managetheatres></managetheatres>'
  });
});
//# sourceMappingURL=managetheatres.js.map
