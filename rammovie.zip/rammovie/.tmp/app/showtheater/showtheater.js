'use strict';

angular.module('meanstackyeomanApp').config(function ($routeProvider) {
  $routeProvider.when('/showtheater', {
    template: '<showtheater></showtheater>'
  }).when('/showtheater/:param', {
    template: '<showtheater></showtheater>'
  });
});
//# sourceMappingURL=showtheater.js.map
