'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var ShowtheaterComponent = function () {
    function ShowtheaterComponent($http, $scope, socket, $routeParams) {
      var _this = this;

      _classCallCheck(this, ShowtheaterComponent);

      this.message = 'Hello';
      this.$http = $http;
      this.socket = socket;
      this.pickedTheatersAll = [];
      this.selectedDates = [];
      this.selectedTimes = [];
      this.theaters = [];
      this.mapping = [];
      this.pickedTheatersAll = [];
      this.movieId = "";
      this.theatreObj = "";
      if ($routeParams) {
        console.log($routeParams.param);
        this.movieId = $routeParams.param;
        //this.theatreObj=$routeParams.param;
        this.$http.get('/api/moviesendpoints/' + this.movieId).then(function (response) {
          console.log(response.data);
          _this.movie = response.data;
          _this.socket.syncUpdates('moviesendpoint', _this.movies);

          _this.$http.get('/api/mappingendpoints').then(function (response1) {
            console.log(response1.data);
            var mappingArray = response1.data;
            for (var variable in mappingArray) {
              console.log(_this.movieId);
              if (mappingArray[variable].MovieObj == _this.movieId) {

                _this.pickedTheatersAll.push(mappingArray[variable]);
                var mov = _this.movieId;
              }
            }

            _this.socket.syncUpdates('mappingendpoint', _this.mapping);
          });
        });
      }
    }

    _createClass(ShowtheaterComponent, [{
      key: '$onInit',
      value: function $onInit() {}
    }]);

    return ShowtheaterComponent;
  }();

  angular.module('meanstackyeomanApp').component('showtheater', {
    templateUrl: 'app/showtheater/showtheater.html',
    controller: ShowtheaterComponent,
    controllerAs: 'showtheaterCtrl'
  });
})();
//# sourceMappingURL=showtheater.controller.js.map
