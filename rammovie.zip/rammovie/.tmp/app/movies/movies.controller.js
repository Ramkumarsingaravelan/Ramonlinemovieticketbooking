'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var MoviesComponent = function () {
    function MoviesComponent($http, $scope, socket) {
      _classCallCheck(this, MoviesComponent);

      this.$http = $http;
      this.socket = socket;
      this.movies = [];
      this.movies_search = [];
      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('movies');
      });
    }

    _createClass(MoviesComponent, [{
      key: 'findmovie',
      value: function findmovie() {
        var _this = this;

        this.$http.get('https://api.themoviedb.org/3/search/movie?api_key=fad4ab5ba39dbc4ce5fc1cd16fdf448a&query=' + this.MovieName + '&year=' + this.Year).then(function (response) {
          // this.$http.get('https://api.themoviedb.org/3/search/movie?api_key=fad4ab5ba39dbc4ce5fc1cd16fdf448a&query=sultan&year=2016').then(response=>{
          _this.movies_search = response.data.results;
          console.log(_this.movies_search);
          //this.socket.syncUpdates('moviesendpoint',this.movies_search);
          /*
             var movieid=response.data.results[0].id;
               this.$http.get('https://api.themoviedb.org/3/movie/'+movieid+'?api_key=fad4ab5ba39dbc4ce5fc1cd16fdf448a').then(movieres=>{
                  this.movies=movieres.data;
                 //console.log(this.movies);
                 this.socket.syncUpdates('moviesendpoint',this.movies);
               });
               */
        });
      }
    }, {
      key: '$onInit',
      value: function $onInit() {
        var _this2 = this;

        this.$http.get('/api/moviesendpoints').then(function (response) {
          _this2.movies = response.data;
          _this2.socket.syncUpdates('moviesendpoint', _this2.movies);
        });
      }
    }, {
      key: 'removemovie',
      value: function removemovie(id) {
        this.$http.delete('/api/moviesendpoints/' + id);
        this.socket.syncUpdates('moviesendpoint', this.movies);
      }
    }, {
      key: 'addmovie',
      value: function addmovie(movieObj) {
        var _this3 = this;

        //console.log(movieObj);
        this.$http.get('https://api.themoviedb.org/3/movie/' + movieObj.id + '?api_key=fad4ab5ba39dbc4ce5fc1cd16fdf448a').then(function (movieres) {

          console.log(movieres.data);

          _this3.$http.post('/api/moviesendpoints', {
            Obj: movieres.data
          }).then(function (response) {
            _this3.$http.get('/api/moviesendpoints').then(function (response1) {
              _this3.movies = response1.data;
              _this3.socket.syncUpdates('moviesendpoint', _this3.movies);
            });
          }, function (failure) {
            console.log(failure);
          });
        });

        //this.socket.syncUpdates('moviesendpoint',this.movies);

        alert('Record Saved Successfully');
        //this.MovieName="";
        //this.Year="";
      }
      //windows.alert('Record Saved Successfully');

    }]);

    return MoviesComponent;
  }();

  angular.module('meanstackyeomanApp').component('movies', {
    templateUrl: 'app/movies/movies.html',
    controller: MoviesComponent,
    styleUrls: ['app/movies/movies.css'],
    controllerAs: 'moviesCtrl'
  });
})();
//# sourceMappingURL=movies.controller.js.map
