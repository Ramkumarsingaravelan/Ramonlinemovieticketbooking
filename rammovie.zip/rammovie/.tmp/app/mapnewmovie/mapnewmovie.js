'use strict';

angular.module('meanstackyeomanApp').config(function ($routeProvider) {
  $routeProvider.when('/mapnewmovie', {
    template: '<mapnewmovie></mapnewmovie>'
  });
});
//# sourceMappingURL=mapnewmovie.js.map
