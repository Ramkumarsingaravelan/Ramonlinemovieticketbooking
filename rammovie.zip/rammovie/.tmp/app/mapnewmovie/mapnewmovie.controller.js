'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var MapnewmovieComponent = function () {
    function MapnewmovieComponent($http, $scope, socket, $rootScope) {
      _classCallCheck(this, MapnewmovieComponent);

      this.$http = $http;
      this.socket = socket;
      this.message = 'Hello';
      this.movieId = '-1';
      this.selectedDates = [];
      this.selectedTimes = [];
      this.selectedTheaters = [];
      this.pickedTheaters = [];
      this.pickedTheatersAll = [];
      this.mapping = [];
      this.movies = [];
      this.theaters = [];
    }

    _createClass(MapnewmovieComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/moviesendpoints').then(function (response) {
          _this.movies = response.data;
          console.log(_this.movies);
          //  this.socket.syncUpdates('moviesendpoint',this.movies);
        });
        this.$http.get('/api/addtheaterendpoints').then(function (response) {
          _this.theaters = response.data;
          console.log(_this.theaters);
        });

        $("#datepicker").datepicker();
        $('input.timepicker').timepicker({

          timeFormat: 'h:mm p',
          interval: 60,
          //minTime: '10',
          //maxTime: '6:00pm',
          //defaultTime: '11',
          //startTime: '10:00',
          dynamic: false,
          dropdown: true,
          scrollbar: true
        });
        //this.socket.syncUpdates('mappingendpoint',this.mappping);

      }
    }, {
      key: 'onChangeMovie',
      value: function onChangeMovie() {
        console.log(this.movieId);
      }
    }, {
      key: 'savemap',
      value: function savemap() {
        var _this2 = this;

        //console.log(this.pickedTheatersAll);
        //console.log(this.selectedTimes);


        this.$http.post('/api/mappingendpoints', {
          MovieObj: this.movieId,
          TheaterObj: this.pickedTheatersAll,
          Dates: this.selectedDates,
          Time: this.selectedTimes
        }).then(function (response) {
          _this2.$http.get('/api/mappingendpoints').then(function (response1) {
            console.log(response1);
            //this.movieId=response1.data;
            //this.pickedTheatersAll=response1.data;
            //this.selectedDates=response1.data;
            //this.selectedTimes=response1.data;

            //this.socket.syncUpdates('mappingendpoint',this.mapping);
          });
        }, function (failure) {
          console.log(failure);
        });
        alert("Record added Successfully");
      }
    }, {
      key: 'onDateBtnClicked',
      value: function onDateBtnClicked() {
        var d = $("#datepicker").val();
        //alert(d);
        this.selectedDates.push(d);
        console.log(this.selectedDates);

        //this.socket.syncUpdates('mappingendpoint',this.selectedDates);
        //sessionStorage.setItem('Dates',this.selectedDates);
        //location.href='/modifyshowdatetimings';
      }
    }, {
      key: 'removedates',
      value: function removedates(ind) {
        //  $timeout(function () {
        this.selectedDates.splice(ind, 1);
        //});
      }
    }, {
      key: 'onTimeBtnClicked',
      value: function onTimeBtnClicked() {
        var t = $('input.timepicker').val();
        //alert(t);
        this.selectedTimes.push(t);
        console.log(this.selectedTimes);
      }
    }, {
      key: 'removetimes',
      value: function removetimes(index) {
        //$timeout(function () {
        this.selectedTimes.splice(index, 1);
        //});
      }
    }, {
      key: 'moveSelectionToRight',
      value: function moveSelectionToRight() {
        var objs = angular.copy(this.selectedTheaters);
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
          for (var _iterator = this.theaters[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var variable = _step.value;
            var _iteratorNormalCompletion2 = true;
            var _didIteratorError2 = false;
            var _iteratorError2 = undefined;

            try {

              for (var _iterator2 = objs[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
                var obj = _step2.value;


                if (obj === variable._id) {
                  this.pickedTheatersAll.push(variable);
                  this.theaters.splice(this.theaters.indexOf(variable), 1);
                  break;
                }
              }

              //console.log(variable);
            } catch (err) {
              _didIteratorError2 = true;
              _iteratorError2 = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion2 && _iterator2.return) {
                  _iterator2.return();
                }
              } finally {
                if (_didIteratorError2) {
                  throw _iteratorError2;
                }
              }
            }
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion && _iterator.return) {
              _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
      }
    }, {
      key: 'moveSelectionToLeft',
      value: function moveSelectionToLeft() {

        var objs = angular.copy(this.pickedTheaters);
        var _iteratorNormalCompletion3 = true;
        var _didIteratorError3 = false;
        var _iteratorError3 = undefined;

        try {
          for (var _iterator3 = this.pickedTheatersAll[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
            var variable = _step3.value;
            var _iteratorNormalCompletion4 = true;
            var _didIteratorError4 = false;
            var _iteratorError4 = undefined;

            try {

              for (var _iterator4 = objs[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
                var obj = _step4.value;

                console.log(obj);
                if (obj === variable._id) {
                  this.theaters.push(variable);
                  console.log(variable);
                  this.pickedTheatersAll.splice(this.pickedTheatersAll.indexOf(variable), 1);
                  break;
                }
              }

              //console.log(variable);
            } catch (err) {
              _didIteratorError4 = true;
              _iteratorError4 = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion4 && _iterator4.return) {
                  _iterator4.return();
                }
              } finally {
                if (_didIteratorError4) {
                  throw _iteratorError4;
                }
              }
            }
          }
        } catch (err) {
          _didIteratorError3 = true;
          _iteratorError3 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion3 && _iterator3.return) {
              _iterator3.return();
            }
          } finally {
            if (_didIteratorError3) {
              throw _iteratorError3;
            }
          }
        }
      }
    }, {
      key: 'moveSelectionToRightall',
      value: function moveSelectionToRightall() {

        var objs = angular.copy(this.pickedTheatersAll);
        this.pickedTheatersAll = [];
        var _iteratorNormalCompletion5 = true;
        var _didIteratorError5 = false;
        var _iteratorError5 = undefined;

        try {
          for (var _iterator5 = objs[Symbol.iterator](), _step5; !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
            var variable = _step5.value;

            this.theaters.push(variable);
            console.log(variable);
          }

          /*
            var objs = angular.copy(this.selectedTheaters);
          for (var variable of this.theaters) {
              for (var obj of objs) {
          //console.log(objs);
              if (obj === variable._id){
                 this.pickedTheatersAll.push(variable);
                this.theaters.splice(this.theaters.indexOf(variable),);
                  break;
                }
              }
                //}
          }
          */
        } catch (err) {
          _didIteratorError5 = true;
          _iteratorError5 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion5 && _iterator5.return) {
              _iterator5.return();
            }
          } finally {
            if (_didIteratorError5) {
              throw _iteratorError5;
            }
          }
        }
      }
    }, {
      key: 'moveSelectionToLeftall',
      value: function moveSelectionToLeftall() {

        var objs = angular.copy(this.theaters);
        this.theaters = [];
        var _iteratorNormalCompletion6 = true;
        var _didIteratorError6 = false;
        var _iteratorError6 = undefined;

        try {
          for (var _iterator6 = objs[Symbol.iterator](), _step6; !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
            var variable = _step6.value;

            this.pickedTheatersAll.push(variable);
            console.log(variable);
          }

          /*
            var objs = angular.copy(this.pickedTheaters);
            for (var variable of this.pickedTheatersAll) {
          
              for (var obj of objs) {
                //console.log(obj);
                if (obj === variable._id){
                  this.theaters.push(variable);
                  //console.log(variable);
                  this.pickedTheatersAll.splice(this.pickedTheatersAll.indexOf(variable));
                  break;
                }
              }
          
          
          
              //console.log(variable);
            }
          
            */
        } catch (err) {
          _didIteratorError6 = true;
          _iteratorError6 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion6 && _iterator6.return) {
              _iterator6.return();
            }
          } finally {
            if (_didIteratorError6) {
              throw _iteratorError6;
            }
          }
        }
      }
    }]);

    return MapnewmovieComponent;
  }();

  angular.module('meanstackyeomanApp').component('mapnewmovie', {
    templateUrl: 'app/mapnewmovie/mapnewmovie.html',
    controller: MapnewmovieComponent,
    controllerAs: 'mapnewmovieCtrl'
  });
})();
//# sourceMappingURL=mapnewmovie.controller.js.map
