'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var PaymentComponent = function () {
    function PaymentComponent($http, $scope, $location, socket) {
      _classCallCheck(this, PaymentComponent);

      this.$http = $http;
      this.socket = socket;
      this.$scope = $scope;
      this.CardNumber = '';
      this.CardName = '';
      this.CVV = '';
    }

    _createClass(PaymentComponent, [{
      key: 'paid',
      value: function paid() {
        var _this = this;

        console.log(this.CardNumber.length);
        if (this.CardNumber.length != 16) {
          alert('card number invalid');
        } else if (!this.CardName) {
          alert('card name is invalid');
        } else if (this.CVV.length != 3) {
          alert('invalid cvv');
        } else {
          alert('everything is correct');
          console.log("called");

          this.$http.post('/api/seatendpoints ', {
            seatno: sessionStorage.Seatno.split(","),
            date: sessionStorage.dates,
            time: sessionStorage.times,
            movieId: sessionStorage.movieId,
            TheaterId: sessionStorage.theaterId
          }).then(function (response) {
            _this.$http.get('/api/seatendpoints ').then(function (response1) {
              console.log(response.data);

              _this.seat = response.data;
              _this.socket.syncUpdates('seatendpoints', _this.seat);
              window.location.href = '/success';
            });
          });
          return false;
        }

        return true;
      }
    }, {
      key: '$onInit',
      value: function $onInit() {
        document.getElementById('divTickets').innerHTML = sessionStorage.getItem('Ticket');
        document.getElementById('divTotal').innerHTML = sessionStorage.getItem('Total');
        document.getElementById('divSeatno').innerHTML = sessionStorage.getItem('Seatno');
        document.getElementById('divgold').innerHTML = sessionStorage.getItem('Gold');
        document.getElementById('divsliver').innerHTML = sessionStorage.getItem('Sliver');
        document.getElementById('divshowdate').innerHTML = sessionStorage.getItem('dates');
        document.getElementById('divshowtime').innerHTML = sessionStorage.getItem('times');
        document.getElementById('divshowmovie').innerHTML = sessionStorage.getItem('MovieName');
        document.getElementById('divshowTheater').innerHTML = sessionStorage.getItem('TheaterName');
        document.getElementById('divshowLocation').innerHTML = sessionStorage.getItem('Location');
        document.getElementById('divshowCity').innerHTML = sessionStorage.getItem('City');
        var id = sessionStorage.getItem("id");
      }
    }]);

    return PaymentComponent;
  }();

  angular.module('meanstackyeomanApp').component('payment', {
    templateUrl: 'app/payment/payment.html',
    controller: PaymentComponent,
    controllerAs: 'paymentCtrl'
  });
})();
//# sourceMappingURL=payment.controller.js.map
