'use strict';

angular.module('meanstackyeomanApp').config(function ($routeProvider) {
  $routeProvider.when('/payment', {
    template: '<payment></payment>'
  });
});
//# sourceMappingURL=payment.js.map
