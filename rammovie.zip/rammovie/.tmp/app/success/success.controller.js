'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var SuccessComponent = function () {
    function SuccessComponent($http, $scope, socket) {
      _classCallCheck(this, SuccessComponent);

      this.$http = $http;
      this.socket = socket;
      this.$scope = $scope;
      //this.message = 'Hello';
    }

    _createClass(SuccessComponent, [{
      key: '$onInit',
      value: function $onInit() {
        //  document.getElementById('divposter').innerHTML=sessionStorage.getItem('Poster');
        document.getElementById('divTickets').innerHTML = sessionStorage.getItem('Ticket');
        document.getElementById('divTotal').innerHTML = sessionStorage.getItem('Total');
        document.getElementById('divSeatno').innerHTML = sessionStorage.getItem('Seatno');
        document.getElementById('divgold').innerHTML = sessionStorage.getItem('Gold');
        document.getElementById('divsliver').innerHTML = sessionStorage.getItem('Sliver');
        document.getElementById('divshowdate').innerHTML = sessionStorage.getItem('dates');
        document.getElementById('divshowtime').innerHTML = sessionStorage.getItem('times');
        document.getElementById('divshowmovie').innerHTML = sessionStorage.getItem('MovieName');
        document.getElementById('divshowTheater').innerHTML = sessionStorage.getItem('TheaterName');
        document.getElementById('divshowLocation').innerHTML = sessionStorage.getItem('Location');
        document.getElementById('divshowCity').innerHTML = sessionStorage.getItem('City');
        var res = sessionStorage.getItem("res");
        sessionStorage.clear();
      }
    }]);

    return SuccessComponent;
  }();

  angular.module('meanstackyeomanApp').component('success', {
    templateUrl: 'app/success/success.html',
    controller: SuccessComponent,
    controllerAs: 'successCtrl'
  });
})();
//# sourceMappingURL=success.controller.js.map
