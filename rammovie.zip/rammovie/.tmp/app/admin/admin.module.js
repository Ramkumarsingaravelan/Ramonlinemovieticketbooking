'use strict';

angular.module('meanstackyeomanApp.admin', ['meanstackyeomanApp.auth', 'ngRoute']);
//# sourceMappingURL=admin.module.js.map
