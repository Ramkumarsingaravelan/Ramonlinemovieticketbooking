'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var AddtheaterComponent = function () {
    function AddtheaterComponent($http, $scope, socket) {
      _classCallCheck(this, AddtheaterComponent);

      this.$http = $http;
      this.socket = socket;
      this.theater = [];

      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('theater');
      });
    }

    _createClass(AddtheaterComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/addtheaterendpoints').then(function (response) {
          _this.theater = response.data;
          console.log(_this.theater);
          _this.socket.syncUpdates('addtheaterendpoint', _this.theater);
        });
      }
    }, {
      key: 'addtheater',
      value: function addtheater() {
        var _this2 = this;

        console.log("called");

        this.$http.post('/api/addtheaterendpoints', {
          TheaterName: this.TheaterName,
          Location: this.Location,
          City: this.City
        }).then(function (response) {
          _this2.$http.get('/api/addtheaterendpoints').then(function (response1) {
            _this2.theatre = response.data;
            _this2.socket.syncUpdates('addtheaterendpoint', _this2.theater);
          });
        });
        this.TheaterName = '';
        this.Location = '';
        this.City = '';
        alert("Record saved Successfully");
      }
    }, {
      key: 'removetheater',
      value: function removetheater(id) {
        this.$http.delete('/api/addtheaterendpoints/' + id);
        this.socket.syncUpdates('addtheaterendpoint', this.theater);
      }
    }]);

    return AddtheaterComponent;
  }();

  angular.module('meanstackyeomanApp').component('addtheater', {
    templateUrl: 'app/addtheater/addtheater.html',
    controller: AddtheaterComponent,
    controllerAs: 'addtheaterCtrl'
  });
})();
//# sourceMappingURL=addtheater.controller.js.map
