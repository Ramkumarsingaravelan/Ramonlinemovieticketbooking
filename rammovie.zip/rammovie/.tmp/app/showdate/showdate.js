'use strict';

angular.module('meanstackyeomanApp').config(function ($routeProvider) {
  $routeProvider.when('/showdate', {
    template: '<showdate></showdate>'
  }).when('/showdate/:movieid/:thid/:mapid', {
    template: '<showdate></showdate>'
  });
});
//# sourceMappingURL=showdate.js.map
