'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var ShowdateComponent = function () {
    function ShowdateComponent($http, $scope, socket, $routeParams) {
      var _this = this;

      _classCallCheck(this, ShowdateComponent);

      this.message = 'Hello';
      this.$http = $http;
      this.socket = socket;
      this.theaterId = '';
      this.mapId = '';
      this.theaterObj = {};
      this.movieId = '';
      this.mappingObj = {};
      this.date = [];
      //this.showdts=false;
      //this.showtic=false;
      if ($routeParams) {
        this.theaterId = $routeParams.thid;
        console.log(this.theaterId);
        this.mapId = $routeParams.mapid;
        this.movieId = $routeParams.movieid;
        this.selectedDate = '';

        this.$http.get('/api/moviesendpoints/' + this.movieId).then(function (response) {
          console.log(response.data);
          _this.movie = response.data;
          var Movieobj = _this.movie;
          sessionStorage.setItem('MovieName', Movieobj.Obj.title);
          sessionStorage.setItem('Poster', Movieobj.Obj.poster_path);
          sessionStorage.setItem('movieId', _this.movieId);
          sessionStorage.setItem('theaterId', _this.theaterId);
          sessionStorage.setItem('mapId', _this.mapId);
          _this.socket.syncUpdates('moviesendpoint', _this.movies);

          _this.$http.get('/api/mappingendpoints/' + _this.mapId).then(function (response1) {

            _this.mappingObj = response1.data;
            console.log(_this.mappingObj);
            var theaters = _this.mappingObj.TheaterObj;

            for (var variable in theaters) {

              if (theaters[variable]._id == _this.theaterId) {

                var Obj = _this.theaterObj = theaters[variable];

                sessionStorage.setItem('TheaterName', Obj.TheaterName);
                sessionStorage.setItem('Location', Obj.Location);
                sessionStorage.setItem('City', Obj.City);
              }
            }

            _this.socket.syncUpdates('mappingendpoint', _this.mapping);
          });
        });
      }
    }

    _createClass(ShowdateComponent, [{
      key: 'selectedDates',
      value: function selectedDates(dts) {
        this.showdts = true;
        //alert(dts);
        var date = this.result = dts;

        sessionStorage.setItem('dates', dts);
      }
    }, {
      key: 'selectedtimes',
      value: function selectedtimes(time) {
        this.showtic = true;
        console.log(time);
        this.res = time;
        sessionStorage.setItem('times', time);
      }
      //gold()
      //{

      //}

    }]);

    return ShowdateComponent;
  }();

  angular.module('meanstackyeomanApp').component('showdate', {
    templateUrl: 'app/showdate/showdate.html',
    controller: ShowdateComponent,
    controllerAs: 'showdateCtrl'
  });
})();
//# sourceMappingURL=showdate.controller.js.map
