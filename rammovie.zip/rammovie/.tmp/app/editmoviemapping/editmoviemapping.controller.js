'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var EditmoviemappingComponent = function EditmoviemappingComponent() {
    _classCallCheck(this, EditmoviemappingComponent);

    this.message = 'Hello';
  };

  angular.module('meanstackyeomanApp').component('editmoviemapping', {
    templateUrl: 'app/editmoviemapping/editmoviemapping.html',
    controller: EditmoviemappingComponent,
    controllerAs: 'editmoviemappingCtrl'
  });
})();
//# sourceMappingURL=editmoviemapping.controller.js.map
