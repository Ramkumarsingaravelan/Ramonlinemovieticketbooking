'use strict';

import mongoose from 'mongoose';

var AddtheaterendpointSchema = new mongoose.Schema({
  TheaterName:String,
  Location:String,
  City:String
});

export default mongoose.model('Addtheaterendpoint', AddtheaterendpointSchema);
