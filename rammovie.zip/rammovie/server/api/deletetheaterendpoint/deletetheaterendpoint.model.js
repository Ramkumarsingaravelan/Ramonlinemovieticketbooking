'use strict';

import mongoose from 'mongoose';

var DeletetheaterendpointSchema = new mongoose.Schema({
  TheaterName:String,
  Location:String,
  City:String
  });

export default mongoose.model('Deletetheaterendpoint', DeletetheaterendpointSchema);
