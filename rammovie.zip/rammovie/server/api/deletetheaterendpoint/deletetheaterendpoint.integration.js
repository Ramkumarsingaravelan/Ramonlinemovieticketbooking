'use strict';

var app = require('../..');
import request from 'supertest';

var newDeletetheaterendpoint;

describe('Deletetheaterendpoint API:', function() {

  describe('GET /api/deletetheaterendpoints', function() {
    var deletetheaterendpoints;

    beforeEach(function(done) {
      request(app)
        .get('/api/deletetheaterendpoints')
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          deletetheaterendpoints = res.body;
          done();
        });
    });

    it('should respond with JSON array', function() {
      expect(deletetheaterendpoints).to.be.instanceOf(Array);
    });

  });

  describe('POST /api/deletetheaterendpoints', function() {
    beforeEach(function(done) {
      request(app)
        .post('/api/deletetheaterendpoints')
        .send({
          name: 'New Deletetheaterendpoint',
          info: 'This is the brand new deletetheaterendpoint!!!'
        })
        .expect(201)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          newDeletetheaterendpoint = res.body;
          done();
        });
    });

    it('should respond with the newly created deletetheaterendpoint', function() {
      expect(newDeletetheaterendpoint.name).to.equal('New Deletetheaterendpoint');
      expect(newDeletetheaterendpoint.info).to.equal('This is the brand new deletetheaterendpoint!!!');
    });

  });

  describe('GET /api/deletetheaterendpoints/:id', function() {
    var deletetheaterendpoint;

    beforeEach(function(done) {
      request(app)
        .get('/api/deletetheaterendpoints/' + newDeletetheaterendpoint._id)
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          deletetheaterendpoint = res.body;
          done();
        });
    });

    afterEach(function() {
      deletetheaterendpoint = {};
    });

    it('should respond with the requested deletetheaterendpoint', function() {
      expect(deletetheaterendpoint.name).to.equal('New Deletetheaterendpoint');
      expect(deletetheaterendpoint.info).to.equal('This is the brand new deletetheaterendpoint!!!');
    });

  });

  describe('PUT /api/deletetheaterendpoints/:id', function() {
    var updatedDeletetheaterendpoint;

    beforeEach(function(done) {
      request(app)
        .put('/api/deletetheaterendpoints/' + newDeletetheaterendpoint._id)
        .send({
          name: 'Updated Deletetheaterendpoint',
          info: 'This is the updated deletetheaterendpoint!!!'
        })
        .expect(200)
        .expect('Content-Type', /json/)
        .end(function(err, res) {
          if (err) {
            return done(err);
          }
          updatedDeletetheaterendpoint = res.body;
          done();
        });
    });

    afterEach(function() {
      updatedDeletetheaterendpoint = {};
    });

    it('should respond with the updated deletetheaterendpoint', function() {
      expect(updatedDeletetheaterendpoint.name).to.equal('Updated Deletetheaterendpoint');
      expect(updatedDeletetheaterendpoint.info).to.equal('This is the updated deletetheaterendpoint!!!');
    });

  });

  describe('DELETE /api/deletetheaterendpoints/:id', function() {

    it('should respond with 204 on successful removal', function(done) {
      request(app)
        .delete('/api/deletetheaterendpoints/' + newDeletetheaterendpoint._id)
        .expect(204)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

    it('should respond with 404 when deletetheaterendpoint does not exist', function(done) {
      request(app)
        .delete('/api/deletetheaterendpoints/' + newDeletetheaterendpoint._id)
        .expect(404)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

  });

});
