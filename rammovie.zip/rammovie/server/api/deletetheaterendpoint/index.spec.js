'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var deletetheaterendpointCtrlStub = {
  index: 'deletetheaterendpointCtrl.index',
  show: 'deletetheaterendpointCtrl.show',
  create: 'deletetheaterendpointCtrl.create',
  update: 'deletetheaterendpointCtrl.update',
  destroy: 'deletetheaterendpointCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var deletetheaterendpointIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './deletetheaterendpoint.controller': deletetheaterendpointCtrlStub
});

describe('Deletetheaterendpoint API Router:', function() {

  it('should return an express router instance', function() {
    expect(deletetheaterendpointIndex).to.equal(routerStub);
  });

  describe('GET /api/deletetheaterendpoints', function() {

    it('should route to deletetheaterendpoint.controller.index', function() {
      expect(routerStub.get
        .withArgs('/', 'deletetheaterendpointCtrl.index')
        ).to.have.been.calledOnce;
    });

  });

  describe('GET /api/deletetheaterendpoints/:id', function() {

    it('should route to deletetheaterendpoint.controller.show', function() {
      expect(routerStub.get
        .withArgs('/:id', 'deletetheaterendpointCtrl.show')
        ).to.have.been.calledOnce;
    });

  });

  describe('POST /api/deletetheaterendpoints', function() {

    it('should route to deletetheaterendpoint.controller.create', function() {
      expect(routerStub.post
        .withArgs('/', 'deletetheaterendpointCtrl.create')
        ).to.have.been.calledOnce;
    });

  });

  describe('PUT /api/deletetheaterendpoints/:id', function() {

    it('should route to deletetheaterendpoint.controller.update', function() {
      expect(routerStub.put
        .withArgs('/:id', 'deletetheaterendpointCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('PATCH /api/deletetheaterendpoints/:id', function() {

    it('should route to deletetheaterendpoint.controller.update', function() {
      expect(routerStub.patch
        .withArgs('/:id', 'deletetheaterendpointCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('DELETE /api/deletetheaterendpoints/:id', function() {

    it('should route to deletetheaterendpoint.controller.destroy', function() {
      expect(routerStub.delete
        .withArgs('/:id', 'deletetheaterendpointCtrl.destroy')
        ).to.have.been.calledOnce;
    });

  });

});
