'use strict';

var app = require('../..');
import request from 'supertest';

var newManagetheatresendpoint;

describe('Managetheatresendpoint API:', function() {

  describe('GET /api/managetheatresendpoints', function() {
    var managetheatresendpoints;

    beforeEach(function(done) {
      request(app)
        .get('/api/managetheatresendpoints')
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          managetheatresendpoints = res.body;
          done();
        });
    });

    it('should respond with JSON array', function() {
      expect(managetheatresendpoints).to.be.instanceOf(Array);
    });

  });

  describe('POST /api/managetheatresendpoints', function() {
    beforeEach(function(done) {
      request(app)
        .post('/api/managetheatresendpoints')
        .send({
          name: 'New Managetheatresendpoint',
          info: 'This is the brand new managetheatresendpoint!!!'
        })
        .expect(201)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          newManagetheatresendpoint = res.body;
          done();
        });
    });

    it('should respond with the newly created managetheatresendpoint', function() {
      expect(newManagetheatresendpoint.name).to.equal('New Managetheatresendpoint');
      expect(newManagetheatresendpoint.info).to.equal('This is the brand new managetheatresendpoint!!!');
    });

  });

  describe('GET /api/managetheatresendpoints/:id', function() {
    var managetheatresendpoint;

    beforeEach(function(done) {
      request(app)
        .get('/api/managetheatresendpoints/' + newManagetheatresendpoint._id)
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          managetheatresendpoint = res.body;
          done();
        });
    });

    afterEach(function() {
      managetheatresendpoint = {};
    });

    it('should respond with the requested managetheatresendpoint', function() {
      expect(managetheatresendpoint.name).to.equal('New Managetheatresendpoint');
      expect(managetheatresendpoint.info).to.equal('This is the brand new managetheatresendpoint!!!');
    });

  });

  describe('PUT /api/managetheatresendpoints/:id', function() {
    var updatedManagetheatresendpoint;

    beforeEach(function(done) {
      request(app)
        .put('/api/managetheatresendpoints/' + newManagetheatresendpoint._id)
        .send({
          name: 'Updated Managetheatresendpoint',
          info: 'This is the updated managetheatresendpoint!!!'
        })
        .expect(200)
        .expect('Content-Type', /json/)
        .end(function(err, res) {
          if (err) {
            return done(err);
          }
          updatedManagetheatresendpoint = res.body;
          done();
        });
    });

    afterEach(function() {
      updatedManagetheatresendpoint = {};
    });

    it('should respond with the updated managetheatresendpoint', function() {
      expect(updatedManagetheatresendpoint.name).to.equal('Updated Managetheatresendpoint');
      expect(updatedManagetheatresendpoint.info).to.equal('This is the updated managetheatresendpoint!!!');
    });

  });

  describe('DELETE /api/managetheatresendpoints/:id', function() {

    it('should respond with 204 on successful removal', function(done) {
      request(app)
        .delete('/api/managetheatresendpoints/' + newManagetheatresendpoint._id)
        .expect(204)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

    it('should respond with 404 when managetheatresendpoint does not exist', function(done) {
      request(app)
        .delete('/api/managetheatresendpoints/' + newManagetheatresendpoint._id)
        .expect(404)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

  });

});
