/**
 * Managetheatresendpoint model events
 */

'use strict';

import {EventEmitter} from 'events';
import Managetheatresendpoint from './managetheatresendpoint.model';
var ManagetheatresendpointEvents = new EventEmitter();

// Set max event listeners (0 == unlimited)
ManagetheatresendpointEvents.setMaxListeners(0);

// Model events
var events = {
  'save': 'save',
  'remove': 'remove'
};

// Register the event emitter to the model events
for (var e in events) {
  var event = events[e];
  Managetheatresendpoint.schema.post(e, emitEvent(event));
}

function emitEvent(event) {
  return function(doc) {
    ManagetheatresendpointEvents.emit(event + ':' + doc._id, doc);
    ManagetheatresendpointEvents.emit(event, doc);
  }
}

export default ManagetheatresendpointEvents;
