'use strict';

import mongoose from 'mongoose';

var ManagetheatresendpointSchema = new mongoose.Schema({
    TheaterName:String,
    Location:String,
    City:String
});

export default mongoose.model('Managetheatresendpoint', ManagetheatresendpointSchema);
