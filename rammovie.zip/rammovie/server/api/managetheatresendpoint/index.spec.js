'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var managetheatresendpointCtrlStub = {
  index: 'managetheatresendpointCtrl.index',
  show: 'managetheatresendpointCtrl.show',
  create: 'managetheatresendpointCtrl.create',
  update: 'managetheatresendpointCtrl.update',
  destroy: 'managetheatresendpointCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var managetheatresendpointIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './managetheatresendpoint.controller': managetheatresendpointCtrlStub
});

describe('Managetheatresendpoint API Router:', function() {

  it('should return an express router instance', function() {
    expect(managetheatresendpointIndex).to.equal(routerStub);
  });

  describe('GET /api/managetheatresendpoints', function() {

    it('should route to managetheatresendpoint.controller.index', function() {
      expect(routerStub.get
        .withArgs('/', 'managetheatresendpointCtrl.index')
        ).to.have.been.calledOnce;
    });

  });

  describe('GET /api/managetheatresendpoints/:id', function() {

    it('should route to managetheatresendpoint.controller.show', function() {
      expect(routerStub.get
        .withArgs('/:id', 'managetheatresendpointCtrl.show')
        ).to.have.been.calledOnce;
    });

  });

  describe('POST /api/managetheatresendpoints', function() {

    it('should route to managetheatresendpoint.controller.create', function() {
      expect(routerStub.post
        .withArgs('/', 'managetheatresendpointCtrl.create')
        ).to.have.been.calledOnce;
    });

  });

  describe('PUT /api/managetheatresendpoints/:id', function() {

    it('should route to managetheatresendpoint.controller.update', function() {
      expect(routerStub.put
        .withArgs('/:id', 'managetheatresendpointCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('PATCH /api/managetheatresendpoints/:id', function() {

    it('should route to managetheatresendpoint.controller.update', function() {
      expect(routerStub.patch
        .withArgs('/:id', 'managetheatresendpointCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('DELETE /api/managetheatresendpoints/:id', function() {

    it('should route to managetheatresendpoint.controller.destroy', function() {
      expect(routerStub.delete
        .withArgs('/:id', 'managetheatresendpointCtrl.destroy')
        ).to.have.been.calledOnce;
    });

  });

});
