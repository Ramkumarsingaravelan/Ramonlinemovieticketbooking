'use strict';

import mongoose from 'mongoose';

var AddtheaterSchema = new mongoose.Schema({
  TheaterName:String,
  Location:String,
  City:String
});

export default mongoose.model('Addtheater', AddtheaterSchema);
