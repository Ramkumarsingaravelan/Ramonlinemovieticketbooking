'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var addtheaterCtrlStub = {
  index: 'addtheaterCtrl.index',
  show: 'addtheaterCtrl.show',
  create: 'addtheaterCtrl.create',
  update: 'addtheaterCtrl.update',
  destroy: 'addtheaterCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var addtheaterIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './addtheater.controller': addtheaterCtrlStub
});

describe('Addtheater API Router:', function() {

  it('should return an express router instance', function() {
    expect(addtheaterIndex).to.equal(routerStub);
  });

  describe('GET /api/addtheaters', function() {

    it('should route to addtheater.controller.index', function() {
      expect(routerStub.get
        .withArgs('/', 'addtheaterCtrl.index')
        ).to.have.been.calledOnce;
    });

  });

  describe('GET /api/addtheaters/:id', function() {

    it('should route to addtheater.controller.show', function() {
      expect(routerStub.get
        .withArgs('/:id', 'addtheaterCtrl.show')
        ).to.have.been.calledOnce;
    });

  });

  describe('POST /api/addtheaters', function() {

    it('should route to addtheater.controller.create', function() {
      expect(routerStub.post
        .withArgs('/', 'addtheaterCtrl.create')
        ).to.have.been.calledOnce;
    });

  });

  describe('PUT /api/addtheaters/:id', function() {

    it('should route to addtheater.controller.update', function() {
      expect(routerStub.put
        .withArgs('/:id', 'addtheaterCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('PATCH /api/addtheaters/:id', function() {

    it('should route to addtheater.controller.update', function() {
      expect(routerStub.patch
        .withArgs('/:id', 'addtheaterCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('DELETE /api/addtheaters/:id', function() {

    it('should route to addtheater.controller.destroy', function() {
      expect(routerStub.delete
        .withArgs('/:id', 'addtheaterCtrl.destroy')
        ).to.have.been.calledOnce;
    });

  });

});
