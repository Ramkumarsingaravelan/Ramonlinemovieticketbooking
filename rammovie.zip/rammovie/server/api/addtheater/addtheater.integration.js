'use strict';

var app = require('../..');
import request from 'supertest';

var newAddtheater;

describe('Addtheater API:', function() {

  describe('GET /api/addtheaters', function() {
    var addtheaters;

    beforeEach(function(done) {
      request(app)
        .get('/api/addtheaters')
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          addtheaters = res.body;
          done();
        });
    });

    it('should respond with JSON array', function() {
      expect(addtheaters).to.be.instanceOf(Array);
    });

  });

  describe('POST /api/addtheaters', function() {
    beforeEach(function(done) {
      request(app)
        .post('/api/addtheaters')
        .send({
          name: 'New Addtheater',
          info: 'This is the brand new addtheater!!!'
        })
        .expect(201)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          newAddtheater = res.body;
          done();
        });
    });

    it('should respond with the newly created addtheater', function() {
      expect(newAddtheater.name).to.equal('New Addtheater');
      expect(newAddtheater.info).to.equal('This is the brand new addtheater!!!');
    });

  });

  describe('GET /api/addtheaters/:id', function() {
    var addtheater;

    beforeEach(function(done) {
      request(app)
        .get('/api/addtheaters/' + newAddtheater._id)
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          addtheater = res.body;
          done();
        });
    });

    afterEach(function() {
      addtheater = {};
    });

    it('should respond with the requested addtheater', function() {
      expect(addtheater.name).to.equal('New Addtheater');
      expect(addtheater.info).to.equal('This is the brand new addtheater!!!');
    });

  });

  describe('PUT /api/addtheaters/:id', function() {
    var updatedAddtheater;

    beforeEach(function(done) {
      request(app)
        .put('/api/addtheaters/' + newAddtheater._id)
        .send({
          name: 'Updated Addtheater',
          info: 'This is the updated addtheater!!!'
        })
        .expect(200)
        .expect('Content-Type', /json/)
        .end(function(err, res) {
          if (err) {
            return done(err);
          }
          updatedAddtheater = res.body;
          done();
        });
    });

    afterEach(function() {
      updatedAddtheater = {};
    });

    it('should respond with the updated addtheater', function() {
      expect(updatedAddtheater.name).to.equal('Updated Addtheater');
      expect(updatedAddtheater.info).to.equal('This is the updated addtheater!!!');
    });

  });

  describe('DELETE /api/addtheaters/:id', function() {

    it('should respond with 204 on successful removal', function(done) {
      request(app)
        .delete('/api/addtheaters/' + newAddtheater._id)
        .expect(204)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

    it('should respond with 404 when addtheater does not exist', function(done) {
      request(app)
        .delete('/api/addtheaters/' + newAddtheater._id)
        .expect(404)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

  });

});
