/**
 * Addtheater model events
 */

'use strict';

import {EventEmitter} from 'events';
import Addtheater from './addtheater.model';
var AddtheaterEvents = new EventEmitter();

// Set max event listeners (0 == unlimited)
AddtheaterEvents.setMaxListeners(0);

// Model events
var events = {
  'save': 'save',
  'remove': 'remove'
};

// Register the event emitter to the model events
for (var e in events) {
  var event = events[e];
  Addtheater.schema.post(e, emitEvent(event));
}

function emitEvent(event) {
  return function(doc) {
    AddtheaterEvents.emit(event + ':' + doc._id, doc);
    AddtheaterEvents.emit(event, doc);
  }
}

export default AddtheaterEvents;
