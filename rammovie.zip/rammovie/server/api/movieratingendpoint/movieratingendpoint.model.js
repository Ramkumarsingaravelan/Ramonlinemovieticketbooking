'use strict';

import mongoose from 'mongoose';

var MovieratingendpointSchema = new mongoose.Schema({
  movieId:String,
  rating:Number,
  userId:String,
});

export default mongoose.model('Movieratingendpoint', MovieratingendpointSchema);
