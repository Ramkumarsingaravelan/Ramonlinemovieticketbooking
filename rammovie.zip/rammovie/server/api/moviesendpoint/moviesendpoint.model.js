'use strict';

import mongoose from 'mongoose';

var MoviesendpointSchema = new mongoose.Schema({

  Obj:Object

});

export default mongoose.model('Movie', MoviesendpointSchema);
