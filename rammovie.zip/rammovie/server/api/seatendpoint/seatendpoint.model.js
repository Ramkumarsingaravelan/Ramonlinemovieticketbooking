'use strict';

import mongoose from 'mongoose';

var SeatendpointSchema = new mongoose.Schema({
  seatno: Array,
  date: String,
  time:String,
  movieId:String,
  TheaterId:String

});

export default mongoose.model('Seatendpoint', SeatendpointSchema);
