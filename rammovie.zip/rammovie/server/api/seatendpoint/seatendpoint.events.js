/**
 * Seatendpoint model events
 */

'use strict';

import {EventEmitter} from 'events';
import Seatendpoint from './seatendpoint.model';
var SeatendpointEvents = new EventEmitter();

// Set max event listeners (0 == unlimited)
SeatendpointEvents.setMaxListeners(0);

// Model events
var events = {
  'save': 'save',
  'remove': 'remove'
};

// Register the event emitter to the model events
for (var e in events) {
  var event = events[e];
  Seatendpoint.schema.post(e, emitEvent(event));
}

function emitEvent(event) {
  return function(doc) {
    SeatendpointEvents.emit(event + ':' + doc._id, doc);
    SeatendpointEvents.emit(event, doc);
  }
}

export default SeatendpointEvents;
