'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var seatendpointCtrlStub = {
  index: 'seatendpointCtrl.index',
  show: 'seatendpointCtrl.show',
  create: 'seatendpointCtrl.create',
  update: 'seatendpointCtrl.update',
  destroy: 'seatendpointCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var seatendpointIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './seatendpoint.controller': seatendpointCtrlStub
});

describe('Seatendpoint API Router:', function() {

  it('should return an express router instance', function() {
    expect(seatendpointIndex).to.equal(routerStub);
  });

  describe('GET /api/seatendpoints', function() {

    it('should route to seatendpoint.controller.index', function() {
      expect(routerStub.get
        .withArgs('/', 'seatendpointCtrl.index')
        ).to.have.been.calledOnce;
    });

  });

  describe('GET /api/seatendpoints/:id', function() {

    it('should route to seatendpoint.controller.show', function() {
      expect(routerStub.get
        .withArgs('/:id', 'seatendpointCtrl.show')
        ).to.have.been.calledOnce;
    });

  });

  describe('POST /api/seatendpoints', function() {

    it('should route to seatendpoint.controller.create', function() {
      expect(routerStub.post
        .withArgs('/', 'seatendpointCtrl.create')
        ).to.have.been.calledOnce;
    });

  });

  describe('PUT /api/seatendpoints/:id', function() {

    it('should route to seatendpoint.controller.update', function() {
      expect(routerStub.put
        .withArgs('/:id', 'seatendpointCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('PATCH /api/seatendpoints/:id', function() {

    it('should route to seatendpoint.controller.update', function() {
      expect(routerStub.patch
        .withArgs('/:id', 'seatendpointCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('DELETE /api/seatendpoints/:id', function() {

    it('should route to seatendpoint.controller.destroy', function() {
      expect(routerStub.delete
        .withArgs('/:id', 'seatendpointCtrl.destroy')
        ).to.have.been.calledOnce;
    });

  });

});
