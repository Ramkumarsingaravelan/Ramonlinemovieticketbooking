'use strict';

var app = require('../..');
import request from 'supertest';

var newSeatendpoint;

describe('Seatendpoint API:', function() {

  describe('GET /api/seatendpoints', function() {
    var seatendpoints;

    beforeEach(function(done) {
      request(app)
        .get('/api/seatendpoints')
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          seatendpoints = res.body;
          done();
        });
    });

    it('should respond with JSON array', function() {
      expect(seatendpoints).to.be.instanceOf(Array);
    });

  });

  describe('POST /api/seatendpoints', function() {
    beforeEach(function(done) {
      request(app)
        .post('/api/seatendpoints')
        .send({
          name: 'New Seatendpoint',
          info: 'This is the brand new seatendpoint!!!'
        })
        .expect(201)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          newSeatendpoint = res.body;
          done();
        });
    });

    it('should respond with the newly created seatendpoint', function() {
      expect(newSeatendpoint.name).to.equal('New Seatendpoint');
      expect(newSeatendpoint.info).to.equal('This is the brand new seatendpoint!!!');
    });

  });

  describe('GET /api/seatendpoints/:id', function() {
    var seatendpoint;

    beforeEach(function(done) {
      request(app)
        .get('/api/seatendpoints/' + newSeatendpoint._id)
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          seatendpoint = res.body;
          done();
        });
    });

    afterEach(function() {
      seatendpoint = {};
    });

    it('should respond with the requested seatendpoint', function() {
      expect(seatendpoint.name).to.equal('New Seatendpoint');
      expect(seatendpoint.info).to.equal('This is the brand new seatendpoint!!!');
    });

  });

  describe('PUT /api/seatendpoints/:id', function() {
    var updatedSeatendpoint;

    beforeEach(function(done) {
      request(app)
        .put('/api/seatendpoints/' + newSeatendpoint._id)
        .send({
          name: 'Updated Seatendpoint',
          info: 'This is the updated seatendpoint!!!'
        })
        .expect(200)
        .expect('Content-Type', /json/)
        .end(function(err, res) {
          if (err) {
            return done(err);
          }
          updatedSeatendpoint = res.body;
          done();
        });
    });

    afterEach(function() {
      updatedSeatendpoint = {};
    });

    it('should respond with the updated seatendpoint', function() {
      expect(updatedSeatendpoint.name).to.equal('Updated Seatendpoint');
      expect(updatedSeatendpoint.info).to.equal('This is the updated seatendpoint!!!');
    });

  });

  describe('DELETE /api/seatendpoints/:id', function() {

    it('should respond with 204 on successful removal', function(done) {
      request(app)
        .delete('/api/seatendpoints/' + newSeatendpoint._id)
        .expect(204)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

    it('should respond with 404 when seatendpoint does not exist', function(done) {
      request(app)
        .delete('/api/seatendpoints/' + newSeatendpoint._id)
        .expect(404)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

  });

});
