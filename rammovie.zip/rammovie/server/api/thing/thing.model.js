'use strict';

import mongoose from 'mongoose';

var ThingSchema = new mongoose.Schema({
  name: String,
  info: String,
  active: Boolean,
  MovieObj: String,
  TheaterObj: Array,
  Dates: Array,
  Time:Array
});

export default mongoose.model('Thing', ThingSchema);
