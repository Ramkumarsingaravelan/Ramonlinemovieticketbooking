'use strict';

import mongoose from 'mongoose';

var MappingendpointSchema = new mongoose.Schema({
  MovieObj: String,
  TheaterObj: Array,
  Dates: Array,
  Time:Array
});

export default mongoose.model('Mappingendpoint', MappingendpointSchema);
